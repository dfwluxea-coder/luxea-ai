
"use strict";

/* =================================
   LUXEA AI - APPLICATION ENGINE
   Version 1.0
================================= */

const LUXEA = {
  chats: [],
  activeChat: null,
  currentTool: "chat",
  isLoading: false
};

/* =================================
   ELEMENTS
================================= */

const elements = {
  sidebar: document.getElementById("sidebar"),
  menuBtn: document.getElementById("menuBtn"),
  newChat: document.getElementById("newChat"),
  newChatMobile: document.getElementById("newChatMobile"),
  chatArea: document.getElementById("chatArea"),
  welcomeScreen: document.getElementById("welcomeScreen"),
  messages: document.getElementById("messages"),
  input: document.getElementById("messageInput"),
  sendBtn: document.getElementById("sendBtn"),
  chatHistory: document.getElementById("chatHistory"),
  attachBtn: document.getElementById("attachBtn"),
  fileInput: document.getElementById("fileInput"),
  settingsBtn: document.getElementById("settingsBtn")
};

/* =================================
   STORAGE
================================= */

function saveChats() {
  try {
    localStorage.setItem(
      "luxea_chats",
      JSON.stringify(LUXEA.chats)
    );
  } catch (error) {
    console.error("Could not save chats:", error);
  }
}

function loadChats() {
  try {
    const saved = localStorage.getItem("luxea_chats");

    if (saved) {
      const parsed = JSON.parse(saved);

      if (Array.isArray(parsed)) {
        LUXEA.chats = parsed;
      }
    }
  } catch (error) {
    console.error("Could not load chats:", error);
    LUXEA.chats = [];
  }

  renderHistory();
}

/* =================================
   CHAT MANAGEMENT
================================= */

function createChat() {
  const chat = {
    id: Date.now().toString(),
    title: "New conversation",
    messages: [],
    createdAt: new Date().toISOString()
  };

  LUXEA.chats.unshift(chat);
  LUXEA.activeChat = chat.id;

  saveChats();
  renderChat();
  renderHistory();

  closeSidebar();
}

function getActiveChat() {
  return LUXEA.chats.find(
    chat => chat.id === LUXEA.activeChat
  );
}

function openChat(id) {
  const chat = LUXEA.chats.find(
    item => item.id === id
  );

  if (!chat) return;

  LUXEA.activeChat = id;

  renderChat();
  renderHistory();

  closeSidebar();
}

/* =================================
   DISPLAY CHAT
================================= */

function renderChat() {
  const chat = getActiveChat();

  elements.messages.replaceChildren();

  if (!chat || chat.messages.length === 0) {
    elements.welcomeScreen.style.display = "block";
    return;
  }

  elements.welcomeScreen.style.display = "none";

  chat.messages.forEach(message => {
    addMessageToScreen(
      message.content,
      message.role
    );
  });

  scrollToBottom();
}

function addMessageToScreen(content, role) {
  const message = document.createElement("div");

  message.className =
    role === "user"
      ? "message user"
      : "message ai";

  message.textContent = content;

  elements.messages.appendChild(message);
}

function scrollToBottom() {
  elements.chatArea.scrollTop =
    elements.chatArea.scrollHeight;
}

/* =================================
   SEND MESSAGE
================================= */

function sendMessage() {
  if (LUXEA.isLoading) return;

  const text = elements.input.value.trim();

  if (!text) return;

  if (!LUXEA.activeChat) {
    createChat();
  }

  const chat = getActiveChat();

  if (!chat) return;

  chat.messages.push({
    role: "user",
    content: text,
    time: new Date().toISOString()
  });

  if (chat.messages.length === 1) {
    chat.title = text.length > 35
      ? text.substring(0, 35) + "..."
      : text;
  }

  elements.input.value = "";
  elements.input.style.height = "auto";

  saveChats();
  renderChat();
  renderHistory();

  showConnectionNotice();
}

/* =================================
   AI CONNECTION NOTICE
================================= */

function showConnectionNotice() {
  const chat = getActiveChat();

  if (!chat) return;

  const notice =
    "LUXEA AI interface is working, but its AI engine is not connected yet. We will connect a real AI model through a secure backend in the next development stage.";

  chat.messages.push({
    role: "assistant",
    content: notice,
    time: new Date().toISOString()
  });

  saveChats();
  renderChat();
}

/* =================================
   CHAT HISTORY
================================= */

function renderHistory() {
  elements.chatHistory.replaceChildren();

  if (LUXEA.chats.length === 0) {
    const empty = document.createElement("p");

    empty.className = "empty-history";
    empty.textContent = "No conversations yet";

    elements.chatHistory.appendChild(empty);
    return;
  }

  LUXEA.chats.forEach(chat => {
    const button = document.createElement("button");

    button.className = "nav-item";

    if (chat.id === LUXEA.activeChat) {
      button.classList.add("active");
    }

    button.textContent = "◈ " + chat.title;

    button.addEventListener("click", () => {
      openChat(chat.id);
    });

    elements.chatHistory.appendChild(button);
  });
}

/* =================================
   NEW CHAT
================================= */

function handleNewChat() {
  createChat();
}

/* =================================
   SIDEBAR
================================= */

function toggleSidebar() {
  elements.sidebar.classList.toggle("open");
}

function closeSidebar() {
  elements.sidebar.classList.remove("open");
}

/* =================================
   AI TOOLS
================================= */

function selectTool(tool) {
  LUXEA.currentTool = tool;

  document.querySelectorAll("[data-tool]").forEach(
    button => {
      button.classList.toggle(
        "active",
        button.dataset.tool === tool
      );
    }
  );

  const toolNames = {
    chat: "AI Chat",
    image: "Image Studio",
    research: "Web Research",
    code: "Coding Assistant",
    files: "File Analysis"
  };

  elements.input.placeholder =
    "Message " + (toolNames[tool] || "LUXEA AI") + "...";

  closeSidebar();
}

/* =================================
   SUGGESTIONS
================================= */

function handleSuggestion(event) {
  const button = event.target.closest("[data-prompt]");

  if (!button) return;

  const prompt = button.dataset.prompt;

  elements.input.value = prompt;

  sendMessage();
}

/* =================================
   FILE UPLOAD
================================= */

function openFilePicker() {
  elements.fileInput.click();
}

function handleFileUpload() {
  const file = elements.fileInput.files[0];

  if (!file) return;

  elements.input.value =
    "Please analyze this file: " + file.name;

  alert(
    "File selected: " + file.name +
    "\n\nFile analysis will become available after we connect the secure AI backend."
  );

  elements.fileInput.value = "";
}

/* =================================
   SETTINGS
================================= */

function openSettings() {
  alert(
    "LUXEA AI Settings\n\n" +
    "Account settings, appearance, privacy and AI preferences will be added in a future update."
  );
}

/* =================================
   KEYBOARD SUPPORT
================================= */

function handleKeyboard(event) {
  if (
    event.key === "Enter" &&
    !event.shiftKey
  ) {
    event.preventDefault();
    sendMessage();
  }
}

/* =================================
   AUTO RESIZE INPUT
================================= */

function resizeInput() {
  elements.input.style.height = "auto";

  elements.input.style.height =
    Math.min(elements.input.scrollHeight, 160) + "px";
}

/* =================================
   EVENT LISTENERS
================================= */

elements.sendBtn.addEventListener(
  "click",
  sendMessage
);

elements.input.addEventListener(
  "keydown",
  handleKeyboard
);

elements.input.addEventListener(
  "input",
  resizeInput
);

elements.newChat.addEventListener(
  "click",
  handleNewChat
);

elements.newChatMobile.addEventListener(
  "click",
  handleNewChat
);

elements.menuBtn.addEventListener(
  "click",
  toggleSidebar
);

elements.attachBtn.addEventListener(
  "click",
  openFilePicker
);

elements.fileInput.addEventListener(
  "change",
  handleFileUpload
);

elements.settingsBtn.addEventListener(
  "click",
  openSettings
);

document.querySelectorAll("[data-tool]").forEach(
  button => {
    button.addEventListener("click", () => {
      selectTool(button.dataset.tool);
    });
  }
);

document.querySelectorAll("[data-prompt]").forEach(
  button => {
    button.addEventListener("click", handleSuggestion);
  }
);

/* =================================
   START APPLICATION
================================= */

function initializeLuxea() {
  loadChats();

  const lastChat = LUXEA.chats[0];

  if (lastChat) {
    LUXEA.activeChat = lastChat.id;
    renderChat();
  }
}

initializeLuxea();

console.log("LUXEA AI initialized successfully.");
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("/sw.js")
      .catch((error) => {
        console.error("LUXEA service worker error:", error);
      });
  });
}
// LUXEA AI service worker registration
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("./sw.js")
      .then(() => {
        console.log("LUXEA AI service worker registered");
      })
      .catch((error) => {
        console.error("Service worker error:", error);
      });
  });
}