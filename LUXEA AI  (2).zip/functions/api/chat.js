
export async function onRequestPost({ request }) {
  try {
    const body = await request.json();

    if (!Array.isArray(body.messages)) {
      return Response.json(
        { error: "A messages array is required." },
        { status: 400 }
      );
    }

    if (body.messages.length > 30) {
      return Response.json(
        { error: "Too many messages." },
        { status: 400 }
      );
    }

    const allowedRoles = ["user", "assistant"];

    const messages = body.messages.filter(
      message =>
        message &&
        allowedRoles.includes(message.role) &&
        typeof message.content === "string"
    );

    if (messages.length !== body.messages.length) {
      return Response.json(
        { error: "Invalid message format." },
        { status: 400 }
      );
    }

    return Response.json({
      reply: "LUXEA AI backend is connected. The AI model will be added next.",
      status: "ready"
    });

  } catch (error) {
    return Response.json(
      { error: "Unable to process your request." },
      { status: 400 }
    );
  }
}
